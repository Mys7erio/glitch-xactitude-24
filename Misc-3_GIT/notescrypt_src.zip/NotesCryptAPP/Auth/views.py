from django.shortcuts import render, redirect
from django.contrib.auth.hashers import make_password, check_password

from .models import Users
from .functions import username_exists, check_credentials


def login(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')

        is_valid_creds = check_credentials(username, password)
        if is_valid_creds:
            request.session['user_authenticated'] = True
            return redirect('/auth/profile')
        else:
            return render(request, 'signin.html', {'error':'Incorrect Username or Password!'})

    return render(request, 'signin.html')


def signup(request):
    if request.method == "POST":
        username = request.POST.get('username')
        password = request.POST.get('password')

        if username_exists(username):
            return render(request, 'signup.html', {'error': 'Username already exists!'})

        new_user = Users(username=username, password=make_password(password))
        new_user.save()

        return redirect("/auth/login")

    return render(request, 'signup.html')


def profile(request):
	if request.session.get('user_authenticated', False):
		return render(request, 'profile.html')
	else:
		return redirect('/auth/login')

def logout(request):
    request.session.clear()
    return redirect('/')

