from django.shortcuts import render
from .models import Notes


def list_notes(request):
	notes = Notes.objects.all()
	return render(request, 'notes.html', {'notes': notes})

def select_note_by_ID(request, nid):
	try:
		note = Notes.objects.get(nid=nid)
	except Notes.DoesNotExist:
		note = ''
	finally:
		return render(request, 'notesbyid.html', {'note': note})


